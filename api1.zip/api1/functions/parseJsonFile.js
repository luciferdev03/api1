const fs = require("fs");
const path = require('path');const now = new Date();
const clc                         = require('cli-color');
const year = now.getFullYear();
const month = ('0' + (now.getMonth() + 1)).slice(-2);
const day = ('0' + now.getDate()).slice(-2);

const options = { hour12: false };
const time = now.toLocaleTimeString([], options);

const formattedDate = `${year}/${month}/${day} ${time}`;
exports.formattedDate = formattedDate;
function parseJsonFile(filename) {
  const basename = path.basename(filename);
  try {
    const json = fs.readFileSync(filename, 'utf8');
    JSON.parse(json); return JSON.parse(json);
  } catch (err) {                  
    if (err instanceof SyntaxError && err.message.startsWith('Unexpected token')) {                          
      console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright('Catto')} Manager`, `There is a ${clc.red.bold(`Syntax Error[1;37m in the ${basename} file`)}`);
    } else {
      console.log(`${clc.whiteBright.bold()}[${formattedDate}] ${clc.blueBright('Catto')} Manager`, `An ${clc.red.bold(`Error`)} occurred while reading the ${basename} file`);
    }
    process.exit(1);
  }
}
exports.parseJsonFile = parseJsonFile;
